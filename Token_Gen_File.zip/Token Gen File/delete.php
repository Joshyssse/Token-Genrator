<?php  
session_start(); 
// Create connection
$servername = "localhost";
$usernamev = "id18294460_luxbot";
$password = "x>q#VUY%UJc)6<kl";
$database = "id18294460_luxfgpbot";
$conn = mysqli_connect($servername, $usernamev, $password, $database);

$disc = $_GET["disc"];

$sql = mysqli_query($conn, "SELECT * FROM discord WHERE discordid = $disc");

$row = mysqli_fetch_array($sql);

if($row["discordid"] == null){
    echo "User Not Found";
} else {
    echo "Success";
    $conn->query("DELETE FROM discord WHERE discordid = '$disc'");
    }
?>