<?php

session_start(); 
// Create connection
$servername = "localhost";
$usernamev = "id18294460_luxbot";
$password = "x>q#VUY%UJc)6<kl";
$database = "id18294460_luxfgpbot";
$conn = mysqli_connect($servername, $usernamev, $password, $database);

$disc = $_GET["disc"];

$sql = mysqli_query($conn, "SELECT * FROM discord WHERE discordid = $disc");

$row = mysqli_fetch_array($sql);

if(empty($disc)){
    echo 'DiscordID Empty';
} else {
    if($row["discordid"] == null){
        
     $n=12; 
     
     function getName($n) { 
     
     $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
      
     $randomString = ''; 
  
     for ($i = 0; $i < $n; $i++) { 
        $index = rand(0, strlen($characters) - 1); 
        $randomString .= $characters[$index]; 
     } 
  
     return $randomString; 
     } 
    
    $token1 = getName($n);
    
    $token2 = "RBX_$token1";
    
    $sql = 'INSERT INTO `discord`(`token`, `discordid`) VALUES ("'.$token2.'","'.$disc.'")';
    
    $result = mysqli_query($conn,$sql);
    
    echo $token2;
    } else {
        echo "User Already Has A Key!";
    }  
}
?>