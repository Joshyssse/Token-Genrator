<?php  
session_start(); 
// Create connection
$servername = "localhost";
$usernamev = "id17344598_combustion";
$password = "/3_F6gs2(Iixdmm2";
$database = "id17344598_combustionmgui";
$conn = mysqli_connect($servername, $usernamev, $password, $database);

$sql = mysqli_query($conn, 'SELECT * FROM discord WHERE token = "'.$_GET["token"].'"');
$row = mysqli_fetch_array($sql);
if($row["token"] == null){
    echo "Invalid Token";
} else {
    echo "Whitelisted";
}
?>
