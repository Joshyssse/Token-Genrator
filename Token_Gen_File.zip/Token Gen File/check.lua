local HttpService = game:GetService("HttpService")
local configure = require(game.ServerScriptService.Configure)
game.Players.PlayerAdded:Connect(function(Player)
  if HttpService:GetAsync("https://ceptic1.x10.mx/?token="..configure.Token) == "Whitelisted" then
     print("Loaded")
  else
     Player:Kick("Invalid Token!")
  end
end)
